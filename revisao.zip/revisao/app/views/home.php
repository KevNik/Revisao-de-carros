<?php namespace Teste?>

<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="../css/home.css">
        <title>Revisão de Carros</title>
    </head>

    <body>

        <div id='barraSuperior'>
            <h1>Sistema de revisão</h1>
        </div>

        <section id="menuInicial" class="menu">
            <div class="hidden">
                <form action='../../app.php' method="get">

                    <h2>Selecione uma opção</h2>

                    <p><input type="submit" id="agendarRevisao" name='agendarRevsiao' value="Agendar Revisão"></p>
                    
                    <p><input type="submit" id="selecionarRevisao" name='selecionarRevsiao' value="Selecionar Revisão"></p>
                    
                    <p><input type="submit" id="alterarRevisao" name='alterarRevsiao' value="Alterar Revisão"></p>
                    
                    <p><input type="submit" id="excluirRevisao" name='excluirRevsiao' value="Excluir"></p>

                </form>
            </div>

            <div id="menuAgendar" class="menu">
                <h2>Digite as informações para cadastrar a revisão</h2>

                <form action="../../app.php" method="POST">
                    <p>INFORMAÇÕES DO PROPRIETÁRIO</p>
                    <fieldset>
                    <p><input type="text" name="nome_proprietario" id="nomeProprietario" value="Nome do proprietário"></p>
                    <p><input type="date" name="anoNascimento_proprietario" id="anoNascimentoProprietario" placeholder="Data Nascimento"></p>
                    <p>Selecione o genêro do cliente</p>
                    <label for="sexoHomem">Homem</label>
                    <input type="radio" name="genero" id="sexoHomem" value="homem" checked='true'>
                    <label for="sexoMulher">Mulher</label>
                    <input type="radio" name="genero" id="sexoMulher" value="mulher">
                    </fieldset>

                    <p>INFORRMAÇÕES DO CARRO</p>
                    <fieldset>
                    <p>Nome do carro: <input type="text" name="nome_carro" id="nomeCarro"></p>
                    <p>Ano do carro: <input type="number" name="nome_carro" id="nomeCarro"></p>
                    <p>Modelo do carro: <input type="text" name="modelo_carro" id="modeloCarro"></p>
                    <p>Marca do carro: <input type="text" name="marca_carro" id="marcaCarro"></p>
                    <p>Placa do carro: <input type="text" name="placa_carro" id="placaCarro"></p>
                    </fieldset>

                    <p>Agendar Revisão <input type="submit" value="Agendar"></p>
                </form>
            </div>
        </section>
        <script src="../js/validar.js"></script>
        <script src="../js/trocarConteudo.js"></script>
    </body>
</html>