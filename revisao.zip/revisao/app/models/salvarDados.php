<?php 

require_once('../../config/connection.php');
require_once('../classes/Carro.php');
require_once('../classes/Proprietario.php');
require_once('../classes/Revisao.php');

public function salvarCarro($nome, $ano, $modelo, $marca, $placa)
{
    $carro = new Carro();
    $carro->receberDados($nome, $ano, $modelo, $marca, $placa);
    $sql = 'INSERT INTO carro VALUES '.$this->id.' '.$this->nome.' '.$this->ano.' '.$this->modelo. ' '.$this->$marca.' '. $this->$placa;
    try{
        mysqli_query($conn, $sql);
    }catch(Exception $e){
        echo $e->getMessage();      
    }
    $this->id++;
    
}

public function salvarPorprietario($nome, $ano, $modelo, $marca, $placa)
{
    $proprietario = new proprietario();
    $proprietario->receberDados($nome, $dataNascimento, $carro, $sexo);
    $sql = 'INSERT INTO proprietario VALUES '.$this->id.' '.$this->nome.' '.$this->dataNascimento.' '.$this->carro. ' '.$this->$sexo;
    try{
        mysqli_query($conn, $sql);
    }catch(Exception $e){
        echo $e->getMessage();      
    }
    $this->id++;
    
}

public function salvarRevisao($proprietario, $data)
{
    $revisao = new Revisao();
    $carro->receberDados($proprietario, $data);
    $sql = 'INSERT INTO revisao VALUES '.$this->proprietario.' '.$this->data;
    try{
        mysqli_query($conn, $sql);
    }catch(Exception $e){
        echo $e->getMessage();      
    }
    $this->id++;
}