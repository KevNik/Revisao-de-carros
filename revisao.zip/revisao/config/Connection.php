<?php

class Connection
{
    static function getParams($host, $port, $dbname, $user, $password)
    {
        $this->host = $host;
        $this->dbname = $dbname;
        $this->user = $user;
        $this->password = $password;
        $this->conn;
        $this->error;
    }
    public function connect()
    {
        $this->conn = mysqli_connect($this->host, $this->user, $this->passqord, $this->dbname);
        if ($this->conn) {
            return $this->conn;
        }else{
            $this->error = mysqli_connect_error($this->conn);
            return $this->error;
        }
    }
}

$conn =  new Connection('localhost', 'root', 'root', 'revisao_carro');

