<?php

$url = 'localhost:8080/revisao';