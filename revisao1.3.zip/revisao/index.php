<?php

require __DIR__ . "/vendor/autoload.php";
require './app/routes/router.php';

use Classe\Carro\Carro;
use CoffeeCode\Router\Router;
use DataBase\Connection\Connection;

$router = new Router($url);

$router->get('/', function ($data){
    require './app/views/home.html';
});

$router->post('/registrarRevisao', function($data){
    require './app/views/registrarRevisao.html';
    var_dump($data);
});

$router->post('/registrarCarro', function($data){
    require './app/views/registrarRevisao';
});

$router->post('/registrarProprietario', function($data){
    require './app/views/registrarRevisao';
});

$router->put('/alterarRevisao/{id}', function($data){
    require './app/views/editar.html';
});

$router->dispatch();
